<?php
namespace App\Livewire;

use Livewire\Component;

class ProductPrintLabel extends Component
{
    public $product;
    public $batch;
    public $product_variation;
    public $selectedBatch;  
    public $selectedVariation;  
    public $start_at_position = 1;
    public $total_labels = 1;

    public function mount($product = null)
    {
        $this->product = $product;
        $this->updatedTotalLabels();
    }

    public function render()
    {
        return view('livewire.product-print-label');
    }

    public function updatedBatch()
    {
        $this->getBatch();
    }

    public function handleTotalLabelsBlur()
    {
        // Não precisa de lógica aqui a não ser que queira adicionar algo
        // específico para quando o campo de labels perde o foco.
    }

    public function updatedTotalLabels()
    {
        // Apenas atualiza a visualização, não chama getBatch()
        // Você pode adicionar lógica adicional aqui se necessário.
    }

    public function getBatch() {
        if ($this->product && $this->product->batches) {
            $this->selectedBatch = $this->product->batches->firstWhere('id', $this->batch);
        } else {
            $this->selectedBatch = null;
        }
    }


    public function getVariation() {
        if ($this->product && $this->product->variations) {
            $this->selectedVariation = $this->product->variations->firstWhere('id', $this->product_variation);
        } else {
            $this->selectedVariation = null;
        }
    }

    public function updateBatch($newValue)
{
    $this->batch = $newValue;
}
}
