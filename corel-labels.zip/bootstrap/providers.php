<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\CustomServiceProvider::class,
    App\Providers\Filament\LoginPanelProvider::class,
];
