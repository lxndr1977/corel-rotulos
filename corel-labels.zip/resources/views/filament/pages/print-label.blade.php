<x-filament-panels::page>
    <livewire:product-print-label :record="$record" />
</x-filament-panels::page>
