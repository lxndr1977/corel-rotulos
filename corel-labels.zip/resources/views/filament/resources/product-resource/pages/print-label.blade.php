<x-filament-panels::page>

    <livewire:product-print-label :product="$record" />

</x-filament-panels::page>
